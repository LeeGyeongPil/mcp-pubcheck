# demo-mcp

Practice example package.

Registry name: mcp-name: io.github.example-user/demo-mcp.
