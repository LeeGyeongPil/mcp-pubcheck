"""Practice example."""
