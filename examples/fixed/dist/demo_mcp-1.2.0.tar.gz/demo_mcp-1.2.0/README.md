# demo-mcp

Practice example package.

<!-- mcp-name: io.github.example-user/demo-mcp -->
